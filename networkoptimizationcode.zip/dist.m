function d=dist(p,s)
d=sqrt((p(1,1)-s(1,1))^2+(p(1,2)-s(1,2))^2);
end